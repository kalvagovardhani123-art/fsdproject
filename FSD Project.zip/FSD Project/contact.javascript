const contactForm = document.getElementById('contact-form');

contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Add your logic here to send the message
    console.log(`Name: ${name}, Email: ${email}, Message: ${message}`);
    // You can use AJAX or fetch API to send the message to the server
});
