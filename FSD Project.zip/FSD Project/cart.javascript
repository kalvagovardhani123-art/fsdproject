// Sample cart data
let cart = [
    { id: 1, name: "Chicken Biryani", price: 8.99, quantity: 1 },
    { id: 2, name: "Grilled Chicken", price: 12.99, quantity: 1 },
    { id: 3, name: "Fresh Fruit Salad", price: 5.99, quantity: 1 }
];

// Function to render cart items
function renderCart() {
    let cartItems = document.getElementById("cart-items");
    cartItems.innerHTML = "";

    let subtotal = 0;
    cart.forEach(item => {
        let row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.name}</td>
            <td><input type="number" value="${item.quantity}" min="1" max="10" id="quantity-${item.id}"></td>
            <td>$${item.price.toFixed(2)}</td>
            <td>$${(item.price * item.quantity).toFixed(2)}</td>
            <td><button id="remove-${item.id}">Remove</button></td>
        `;
        cartItems.appendChild(row);

        subtotal += item.price * item.quantity;

        // Add event listener to remove button
        document.getElementById(`remove-${item.id}`).addEventListener("click", () => {
            cart = cart.filter(i => i.id !== item.id);
            renderCart();
        });

        // Add event listener to quantity input
        document.getElementById(`quantity-${item.id}`).addEventListener("change", (e) => {
            item.quantity = parseInt(e.target.value);
            renderCart();
        });
    });

    let tax = subtotal * 0.08;
    let total = subtotal + tax;

    document.getElementById("subtotal").textContent = subtotal.toFixed(2);
    document.getElementById("tax").textContent = tax.toFixed(2);
    document.getElementById("total").textContent = total.toFixed(2);
}

// Render cart on page load
renderCart();