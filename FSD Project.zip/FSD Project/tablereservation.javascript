// Add event listener to reservation form
document.getElementById("reservation-form").addEventListener("submit", (e) => {
    e.preventDefault();

    // Get form data
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let date = document.getElementById("date").value;
    let time = document.getElementById("time").value;
    let guests = document.getElementById("guests").value;

    // Create reservation object
    let reservation = {
        name: name,
        email: email,
        phone: phone,
        date: date,
        time: time,
        guests: guests
    };

    // Send reservation to server
    fetch("/api/reservations", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(reservation)
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));
});