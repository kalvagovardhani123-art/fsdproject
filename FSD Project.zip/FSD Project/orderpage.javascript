// Add event listener to order form
document.getElementById("order-form").addEventListener("submit", (e) => {
    e.preventDefault();

    // Get form data
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let address = document.getElementById("address").value;
    let paymentMethod = document.getElementById("payment-method").value;

    // Create order object
    let order = {
        name: name,
        email: email,
        phone: phone,
        address: address,
        paymentMethod: paymentMethod,
        items: [] // Add cart items here
    };

    // Send order to server
    fetch("/api/orders", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(order)
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));
});
