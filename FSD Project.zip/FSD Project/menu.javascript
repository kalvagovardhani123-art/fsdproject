// Add event listener to menu items
const menuItems = document.querySelectorAll('.menu-category li');

menuItems.forEach(item => {
    item.addEventListener('click', () => {
        // Add your logic here to handle menu item click
        console.log(item.querySelector('.dish-name').textContent);
    });
});